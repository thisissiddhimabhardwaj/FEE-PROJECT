import React from 'react';import{createRoot}from'react-dom/client';import{BrowserRouter}from'react-router-dom';import{Store}from'./store';import App from './App';import './styles.css';
createRoot(document.getElementById('root')).render(<React.StrictMode><BrowserRouter><Store><App/></Store></BrowserRouter></React.StrictMode>);
